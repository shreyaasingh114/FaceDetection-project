# Face Detection with OpenCV

This is a simple face detection project using OpenCV and Haar Cascade Classifiers.

## Features

- Detects faces in real-time using your webcam.
- Uses Haar cascades for face and eye detection.
- Includes a simple camera test script.

## Requirements

Install the required Python packages using:

```bash
pip install -r requirements.txt
```

## Files

- `faceDetection.py`: Detects faces using Haar cascades.
- `simpleCamTest.py`: Tests the webcam and shows BGR and grayscale video.
- `haarcascade_frontalface_default.xml`: Face detection classifier.
- `haarcascade_eye.xml`: Eye detection classifier.

## How to Run

1. Connect a webcam.
2. Run the script:

```bash
python faceDetection.py
```

Press `ESC` to exit the detection window.

## Credits

Based on tutorials from:
- https://pythonprogramming.net
- Adapted by Marcelo Rovai (MJRoBot.org)
